package com.zosh.domain;

public enum USER_ROLE {
	

	    ROLE_CUSTOMER,
	    ROLE_RESTAURANT_OWNER,
	ROLE_RESTAURANT_MANAGER,
	    ROLE_ADMIN
	


}
