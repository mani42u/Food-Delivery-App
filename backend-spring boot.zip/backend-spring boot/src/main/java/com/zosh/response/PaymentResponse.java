package com.zosh.response;

public class PaymentResponse {
    private String payment_url;
}
